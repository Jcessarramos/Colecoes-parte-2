package mod12;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class MeF {
	public static void main(String[] args) {
        List<Pessoa> pessoas = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        
       
            while (true) {
            System.out.println("Digite o nome e o sexo da pessoa: (Caso mão queira, digite 'fim'.)");
            String input = scanner.nextLine();
            
          
            if (input.equalsIgnoreCase("fim")) {
                break;
            }
            
         
            String[] dados = input.split(" ");
            String nome = dados[0];
            String genero = dados[1];
            
            
            Pessoa pessoa = new Pessoa(nome, genero);
            pessoas.add(pessoa);
        }
     
        separarPorGenero(pessoas);
        scanner.close();
    }

    private static void separarPorGenero(List<Pessoa> pessoas) {
        List<Pessoa> homens = new LinkedList<>();
        List<Pessoa> mulheres = new LinkedList<>();

        for (Pessoa pessoa : pessoas) {
            if (pessoa.getGenero().equalsIgnoreCase("M")) {
                homens.add(pessoa);
            } else if (pessoa.getGenero().equalsIgnoreCase("F")) {
                mulheres.add(pessoa);
            }
        }

        System.out.println("Homens:");
        for (Pessoa homem : homens) {
            System.out.println(homem.getNome());
        }

        System.out.println("\nMulheres:");
        for (Pessoa mulher : mulheres) {
            System.out.println(mulher.getNome());
        }
    }
}

class Pessoa {
    private String nome;
    private String genero;

    public Pessoa(String nome, String genero) {
        this.nome = nome;
        this.genero = genero;
    }

    public String getNome() {
        return nome;
    }

    public String getGenero() {
        return genero;
    }
}
